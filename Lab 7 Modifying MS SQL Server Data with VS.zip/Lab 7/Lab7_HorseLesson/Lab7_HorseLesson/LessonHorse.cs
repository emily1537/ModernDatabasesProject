namespace Lab7_HorseLesson
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("LessonHorse")]
    public partial class LessonHorse
    {
        public int LessonHorseID { get; set; }

        public int HorseID { get; set; }

        public int SchedLessonID { get; set; }

        public virtual Horse Horse { get; set; }

        public virtual ScheduledLesson ScheduledLesson { get; set; }
    }
}
