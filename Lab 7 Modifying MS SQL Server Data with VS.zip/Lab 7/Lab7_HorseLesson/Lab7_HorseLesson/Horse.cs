namespace Lab7_HorseLesson
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Horse")]
    public partial class Horse
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Horse()
        {
            LessonHorses = new HashSet<LessonHorse>();
        }

        public int HorseID { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public DateTime VaccDate { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<LessonHorse> LessonHorses { get; set; }
    }
}
