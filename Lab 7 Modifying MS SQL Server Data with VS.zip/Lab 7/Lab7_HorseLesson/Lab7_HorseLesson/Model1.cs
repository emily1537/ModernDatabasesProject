namespace Lab7_HorseLesson
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=HorseLessonModel1")
        {
        }

        public virtual DbSet<Horse> Horses { get; set; }
        public virtual DbSet<Lesson> Lessons { get; set; }
        public virtual DbSet<LessonHorse> LessonHorses { get; set; }
        public virtual DbSet<ScheduledLesson> ScheduledLessons { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<StudentLesson> StudentLessons { get; set; }
        public virtual DbSet<Teacher> Teachers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Horse>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Horse>()
                .HasMany(e => e.LessonHorses)
                .WithRequired(e => e.Horse)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Lesson>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Lesson>()
                .Property(e => e.Price)
                .HasPrecision(5, 2);

            modelBuilder.Entity<Lesson>()
                .HasMany(e => e.ScheduledLessons)
                .WithRequired(e => e.Lesson)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ScheduledLesson>()
                .HasMany(e => e.LessonHorses)
                .WithRequired(e => e.ScheduledLesson)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ScheduledLesson>()
                .HasMany(e => e.StudentLessons)
                .WithRequired(e => e.ScheduledLesson)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Student>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Student>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Student>()
                .Property(e => e.EmContactPhone)
                .IsUnicode(false);

            modelBuilder.Entity<Student>()
                .HasMany(e => e.StudentLessons)
                .WithRequired(e => e.Student)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Teacher>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Teacher>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Teacher>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<Teacher>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<Teacher>()
                .HasMany(e => e.ScheduledLessons)
                .WithRequired(e => e.Teacher)
                .WillCascadeOnDelete(false);
        }
    }
}
