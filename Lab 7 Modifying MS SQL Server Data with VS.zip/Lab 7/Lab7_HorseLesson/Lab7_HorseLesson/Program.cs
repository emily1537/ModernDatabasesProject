﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_HorseLesson
{
    class Program
    {
        static void Main(string[] args)
        {
            using(Lab7_HorseLesson.Model1 db = new Model1())
            {
                List<StudentLesson> presentStudents = db.StudentLessons.Where(c => c.Present == true).ToList();

                StudentLesson StuLessToDelete = db.StudentLessons.ToArray().Last();

                if(StuLessToDelete != null)
                {
                    db.StudentLessons.Remove(StuLessToDelete);
                    db.SaveChanges();
                }


                foreach (StudentLesson c in presentStudents)
                {
                    Console.WriteLine("StudentLessonID: {0} SchedLessonID: {1} StudentID: {2} Present: {3}",
                        c.StudentLessonID, c.SchedLessonID, c.StudentID, c.Present);
                }

                //Lesson lessonToAdd = new Lesson { LessonID = 6, Name = "Dressage", Price = 150, MinAge = 12 };
                //db.Lessons.Add(lessonToAdd);
                //db.SaveChanges();

                //Lesson newLesson = db.Lessons.Where(b => b.LessonID == 6).SingleOrDefault();

                //if(newLesson != null)
                //{
                //    Console.WriteLine("Lesson ID: {0} Lesson Name: {1} Price: {2} Minimum Age: {3}",
                //        newLesson.LessonID, newLesson.Name, newLesson.Price, newLesson.MinAge);
                //}

                Console.ReadLine();
            }
        }
    }
}
