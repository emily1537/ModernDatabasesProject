namespace Lab7_HorseLesson
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("StudentLesson")]
    public partial class StudentLesson
    {
        public int StudentLessonID { get; set; }

        public int StudentID { get; set; }

        public bool Present { get; set; }

        public int SchedLessonID { get; set; }

        public virtual ScheduledLesson ScheduledLesson { get; set; }

        public virtual Student Student { get; set; }
    }
}
