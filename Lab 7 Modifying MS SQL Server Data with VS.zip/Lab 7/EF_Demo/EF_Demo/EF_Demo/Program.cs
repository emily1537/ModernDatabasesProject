﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            using (EF_Demo.LakeShoreModel1 db = new LakeShoreModel1())
            {
                List<Crew> activeCrew = db.Crews.Where(c => c.Status == "Active").ToList();

                //foreach(Crew c in activeCrew)
                //{
                //    Console.WriteLine("{0} {1} {2} {3}", c.CrewId, c.FirstName, c.LastName, c.Position.Name);
                //}

                //Crew crewPersonToAdd = new Crew { FirstName = "Mark", LastName = "Thomposon", PositionId = 1, Status = "Active", EmContactName = "Mary Thompson", EmContanctPhone = "405-568-78654", EmContactRelationship = "Mother" };
                //db.Crews.Add(crewPersonToAdd);
                //db.SaveChanges();


                

                //Boat boat5 = db.Boats.Where(b => b.BoatId == 5).SingleOrDefault();
                //if (boat5 != null)
                //{
                //    Console.WriteLine("ID: {0} Name: {1} Capicity: {2}", boat5.BoatId, boat5.Name, boat5.Capacity);
                //}

                Crew crewToDelete = db.Crews.ToArray().Last();
                if (crewToDelete != null)
                {
                    db.Crews.Remove(crewToDelete);
                    db.SaveChanges();
                }

                activeCrew = db.Crews.Where(c => c.Status == "Active").ToList();

                foreach (Crew c in activeCrew)
                {
                    Console.WriteLine("{0} {1} {2} {3}", c.CrewId, c.FirstName, c.LastName, c.Position.Name);
                }

                Console.ReadLine();
            }
        }
    }
}
