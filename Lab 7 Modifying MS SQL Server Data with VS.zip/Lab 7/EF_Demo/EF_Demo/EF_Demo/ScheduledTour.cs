namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ScheduledTour")]
    public partial class ScheduledTour
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ScheduledTour()
        {
            ScheduledCrews = new HashSet<ScheduledCrew>();
        }

        [Key]
        public int SchTourId { get; set; }

        public DateTime TourStart { get; set; }

        public DateTime TourEnd { get; set; }

        public int TourId { get; set; }

        public int BoatId { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; }

        public int PatronCapacity { get; set; }

        public virtual Boat Boat { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScheduledCrew> ScheduledCrews { get; set; }

        public virtual Tour Tour { get; set; }
    }
}
