namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Crew")]
    public partial class Crew
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Crew()
        {
            ScheduledCrews = new HashSet<ScheduledCrew>();
        }

        public int CrewId { get; set; }

        public int SupervisorId { get; set; }

        [Required]
        [StringLength(60)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(60)]
        public string LastName { get; set; }

        public int PositionId { get; set; }

        [Required]
        [StringLength(30)]
        public string Status { get; set; }

        [Required]
        [StringLength(255)]
        public string EmContactName { get; set; }

        [Required]
        [StringLength(14)]
        public string EmContanctPhone { get; set; }

        [Required]
        [StringLength(30)]
        public string EmContactRelationship { get; set; }

        public virtual Position Position { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScheduledCrew> ScheduledCrews { get; set; }
    }
}
