namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Boat")]
    public partial class Boat
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Boat()
        {
            ScheduledTours = new HashSet<ScheduledTour>();
        }

        public int BoatId { get; set; }

        [Required]
        [StringLength(50)]
        public string BoatType { get; set; }

        [Required]
        [StringLength(50)]
        public string RegNumber { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public int Capacity { get; set; }

        public int NumCrewRequired { get; set; }

        [Required]
        [StringLength(20)]
        public string FuelType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScheduledTour> ScheduledTours { get; set; }
    }
}
