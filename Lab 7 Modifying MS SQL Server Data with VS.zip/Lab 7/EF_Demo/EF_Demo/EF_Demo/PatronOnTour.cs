namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PatronOnTour")]
    public partial class PatronOnTour
    {
        [Key]
        public int PatronTourId { get; set; }

        public int SchTourId { get; set; }

        public int PatronId { get; set; }

        public int NumPassengers { get; set; }

        [Required]
        [StringLength(10)]
        public string PaymentStatus { get; set; }

        [StringLength(30)]
        public string PaymentType { get; set; }

        [StringLength(100)]
        public string PaymentReference { get; set; }

        public int? Rating { get; set; }

        public virtual Patron Patron { get; set; }
    }
}
