namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ScheduledCrew")]
    public partial class ScheduledCrew
    {
        [Key]
        public int TourCrewId { get; set; }

        public int CrewId { get; set; }

        public bool OnBoard { get; set; }

        public int SchTourId { get; set; }

        public virtual Crew Crew { get; set; }

        public virtual ScheduledTour ScheduledTour { get; set; }
    }
}
