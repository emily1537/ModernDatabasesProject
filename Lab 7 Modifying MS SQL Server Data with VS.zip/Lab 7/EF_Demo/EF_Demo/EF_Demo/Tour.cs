namespace EF_Demo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Tour")]
    public partial class Tour
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Tour()
        {
            ScheduledTours = new HashSet<ScheduledTour>();
        }

        public int TourId { get; set; }

        [Required]
        [StringLength(60)]
        public string Name { get; set; }

        public decimal Price { get; set; }

        public bool MealIncluded { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScheduledTour> ScheduledTours { get; set; }
    }
}
