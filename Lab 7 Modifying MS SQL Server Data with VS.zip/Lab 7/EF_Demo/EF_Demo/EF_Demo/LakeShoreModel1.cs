namespace EF_Demo
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class LakeShoreModel1 : DbContext
    {
        public LakeShoreModel1()
            : base("name=LakeShoreModel1")
        {
        }

        public virtual DbSet<Boat> Boats { get; set; }
        public virtual DbSet<Crew> Crews { get; set; }
        public virtual DbSet<Patron> Patrons { get; set; }
        public virtual DbSet<PatronOnTour> PatronOnTours { get; set; }
        public virtual DbSet<Position> Positions { get; set; }
        public virtual DbSet<ScheduledCrew> ScheduledCrews { get; set; }
        public virtual DbSet<ScheduledTour> ScheduledTours { get; set; }
        public virtual DbSet<Tour> Tours { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Boat>()
                .Property(e => e.BoatType)
                .IsUnicode(false);

            modelBuilder.Entity<Boat>()
                .Property(e => e.RegNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Boat>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Boat>()
                .Property(e => e.FuelType)
                .IsUnicode(false);

            modelBuilder.Entity<Boat>()
                .HasMany(e => e.ScheduledTours)
                .WithRequired(e => e.Boat)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.EmContactName)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.EmContanctPhone)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.EmContactRelationship)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .HasMany(e => e.ScheduledCrews)
                .WithRequired(e => e.Crew)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.OrgName)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.Street)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.State)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.Zipcode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .Property(e => e.PatronType)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Patron>()
                .HasMany(e => e.PatronOnTours)
                .WithRequired(e => e.Patron)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PatronOnTour>()
                .Property(e => e.PaymentStatus)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<PatronOnTour>()
                .Property(e => e.PaymentType)
                .IsUnicode(false);

            modelBuilder.Entity<PatronOnTour>()
                .Property(e => e.PaymentReference)
                .IsUnicode(false);

            modelBuilder.Entity<Position>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Position>()
                .HasMany(e => e.Crews)
                .WithRequired(e => e.Position)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ScheduledTour>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<ScheduledTour>()
                .HasMany(e => e.ScheduledCrews)
                .WithRequired(e => e.ScheduledTour)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tour>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Tour>()
                .Property(e => e.Price)
                .HasPrecision(10, 2);

            modelBuilder.Entity<Tour>()
                .HasMany(e => e.ScheduledTours)
                .WithRequired(e => e.Tour)
                .WillCascadeOnDelete(false);
        }
    }
}
